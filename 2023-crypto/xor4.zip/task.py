from secret import flag
import random

k = random.randint(0, 255)

cipher = ""
for c in flag:
    cipher += chr(ord(c) ^ k)

with open("cipher", "w") as f:
    f.write(cipher)