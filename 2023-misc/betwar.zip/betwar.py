# coding=utf-8
import socket
import thread
import os

flag="flag{xxxxxx}"
guesture=['j','s','b']
def iswin(me,you):
    if me==you:
        return 0
    if me=='s' and you=='j':
        return 1
    if me=='s' and you=='b':
        return -1
    if me=='j' and you=='s':
        return -1
    if me=='j' and you=='b':
        return 1
    if me=='b' and you=='s':
        return 1
    if me=='b' and you=='j':
        return -1

def train(conn):
    mapp=[[0,0,0],[0,0,0],[0,0,0]]
    for i in range(100):
        conn.send("your claim(j s b):")
        player_claim=conn.recv(1024).strip()
        server_claim=guesture[int(os.urandom(2).encode("hex"),16)%3]
        conn.send("my claim:"+server_claim+"\n")
        conn.send("your decision(j s b):")
        player_decision=conn.recv(1024).strip()
        server_decision=guesture[int(os.urandom(2).encode("hex"), 16) % 3]
        conn.send("my decision:"+server_decision+"\n")
        mapp[guesture.index(player_claim)][guesture.index(player_decision)]+=1
        conn.send("result:"+str(iswin(player_decision,server_decision)))
    return mapp

def choose_decision(mapp,player_claim,player,server):
    ai_choose_decision='j'
    max_num=0
    for i in range(3):
        if mapp[guesture.index(player_claim)][i]>max_num:
            max_num=mapp[guesture.index(player_claim)][i]
            ai_choose_decision=guesture[i]
    if player[guesture.index(ai_choose_decision)]==0:
        ai_choose_decision=guesture[(guesture.index(ai_choose_decision)+1)%3]
    if player[guesture.index(ai_choose_decision)]==0:
        ai_choose_decision=guesture[(guesture.index(ai_choose_decision)+1)%3]

    defeat_decision=-5
    for i in range(3):
        if iswin(guesture[i],ai_choose_decision)==1:
            defeat_decision=guesture[i]
    assert defeat_decision!=-5
    if server[guesture.index(defeat_decision)]==0:
        defeat_decision=guesture[(guesture.index(defeat_decision)+1)%3]
    if server[guesture.index(defeat_decision)]==0:
        defeat_decision=guesture[(guesture.index(defeat_decision)+1)%3]
    return defeat_decision

def war(conn,mapp):
    player=[10,10,10]
    server=[10,10,10]
    score=0
    for i in range(30):
        conn.send("score:%d\n" % score)
        conn.send("player left:%dj %ds %db\n" % (player[0], player[1], player[2]))
        conn.send("server left:%dj %ds %db\n" % (server[0], server[1], server[2]))
        conn.send("your claim(j s b):")
        player_claim=conn.recv(1024).strip()
        server_claim=guesture[int(os.urandom(2).encode("hex"),16)%3]
        conn.send("my claim:"+server_claim+"\n")
        conn.send("your decision(j s b):")
        player_decision=conn.recv(1024).strip()
        server_decision=choose_decision(mapp,player_claim,player,server)
        conn.send("my decision:"+server_decision+"\n")
        player[guesture.index(player_decision)]-=1
        server[guesture.index(server_decision)]-=1
        if iswin(server_decision,player_decision)==1:
            score-=1
        if iswin(server_decision,player_decision)==-1:
            score+=1
    conn.send("score:%d\n" % score)
    conn.send("player left:%dj %ds %db\n" % (player[0], player[1], player[2]))
    conn.send("server left:%dj %ds %db\n" % (server[0], server[1], server[2]))
    if score==30:
        conn.send(flag+"\n")



def remote_sub(conn, address):
    print address
    conn.send("training-process\n")
    mapp=train(conn)
    war(conn,mapp)
    return

def remote():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", 10003))
    sock.listen(0)
    while True:
        thread.start_new_thread(remote_sub, sock.accept())
if __name__ == '__main__':
    remote()
